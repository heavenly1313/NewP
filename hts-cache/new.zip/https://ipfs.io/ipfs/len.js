ipfs resolve -r /ipfs/len.js: invalid path "/ipfs/len.js": invalid CID: selected encoding not supported
